package com.java.practice;

public class Manager extends Employee{
	Manager(String name,String addr, double Sal,String JobTitle){
		super(name,addr,Sal,JobTitle);
		this.JobTitle = "Manager";
	}
	
	public void calculateBonus() {
		System.out.println("Bonus Calculation in Manager Class");
		double bonus = (0.05* this.Salary);
		double updatedSal = this.Salary + bonus;
		System.out.println("Updated salary of the associate:"+updatedSal);
	}
	
	public void getPerformanceReport() {
		System.out.println("Manager:Performance report generated");
	}

	public void getManagingProjects() {
		System.out.println("Manager:Projects");
	}
}
