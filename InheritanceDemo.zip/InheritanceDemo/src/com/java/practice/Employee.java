package com.java.practice;

public class Employee {
	
	String name;
	String Address;
	double Salary;
	String JobTitle;
	
	Employee(String name,String addr, double Sal,String JobTitle){
		this.name = name;
		this.Address = addr;
		this.Salary = Sal;
		this.JobTitle = JobTitle;
	}
	
	public void calculateBonus() {
		System.out.println("Bonus Calculation");
	}

}

