package com.java.practice;

public class Main {

	public static void main(String[] args) {
		Manager obj1 = new Manager("John","Street1, XXX", 1000.00, "");
		Developer dev1 = new Developer("Jason", "Street2, YYY", 1000.00,"");
		Programmer prog1 = new Programmer("Langdon", "ZZZ", 1000.00,"");
		
		obj1.calculateBonus();
		dev1.calculateBonus();
		prog1.calculateBonus();
		
		obj1.getManagingProjects();
		dev1.getPerformanceReport();

	}

}
