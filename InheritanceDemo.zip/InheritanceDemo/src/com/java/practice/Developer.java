package com.java.practice;

public class Developer extends Employee{
	Developer(String name,String addr, double Sal,String JobTitle){
		super(name,addr,Sal,JobTitle);
		this.JobTitle = "Developer";
	}
	 
	public void calculateBonus() {
		System.out.println("Bonus Calculation in Developer Class");
		double bonus = (0.1* this.Salary);
		double updatedSal = this.Salary + bonus;
		System.out.println("Updated salary of the associate:"+updatedSal);
	}
	
	public void getPerformanceReport() {
		System.out.println("Developer:Performance report generated");
	}
	public void getManagingProjects() {
		System.out.println("Developer:Projects");
	}


	

}
