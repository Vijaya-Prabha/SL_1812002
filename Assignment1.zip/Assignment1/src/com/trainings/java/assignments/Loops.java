package com.trainings.java.assignments;

import java.util.Scanner;

public class Loops {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the start value:");
		int start = sc.nextInt();
		System.out.println("Enter the end value:");
		int end = sc.nextInt();
		while(start<=end) {
			System.out.println(start);
			start++;
		}
	}

}
