package com.trainings.java.assignments;

public class TriangleAreaPerimeter {
	double sideA ,sideB,sideC = 0.0;
	TriangleAreaPerimeter(double a,double b, double c){
		this.sideA=a;
		this.sideB=b;
		this.sideC=c;
	}
	
	private void getPerimeter() {
		double result = (this.sideA + this.sideB + this.sideC);
		System.out.println("Perimeter of the given Traingle :" + (int)result);
	}
	
	private void getArea() {
		double temp = ((this.sideA + this.sideB + this.sideC) / 2);
		double result = Math.sqrt(temp * (temp-this.sideA)* (temp-this.sideB)*(temp-this.sideC));
		System.out.println("Area of the given Traingle :" + result);
	}
	
	public static void main(String[] args) {
		TriangleAreaPerimeter obj1= new TriangleAreaPerimeter(2,6,7);
		obj1.getArea();
		obj1.getPerimeter();
	}

}
