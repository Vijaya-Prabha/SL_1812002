package com.trainings.java.assignments;

import java.util.Random;
import java.util.Scanner;

public class GuessGame {

	public static void main(String[] args) {
		Random randomNum = new Random();
		int numberToBeGuessed = randomNum.nextInt(100);
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Guess:");
	    int userInput = sc.nextInt();
	    while(userInput!=numberToBeGuessed) {
	    	if(userInput<numberToBeGuessed) {
	    		System.out.println("You number is lower than the expected value.Guess again");
	    	}
	    	else if (userInput> numberToBeGuessed) {
	    		System.out.println("You number is higher than the expected value.Guess again");
	    	}
	    	userInput = sc.nextInt();
	    }
    		System.out.println("Hurray!!You guessed it right");
	}

}
