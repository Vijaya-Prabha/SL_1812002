package superKeywordDemo;

public class Test {

	public static void main(String[] args) {
		Employee E1 = new Employee("John", 100, "Developer");
		E1.display();

	}

}
