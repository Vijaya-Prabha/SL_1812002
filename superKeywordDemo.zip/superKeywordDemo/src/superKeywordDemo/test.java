package superKeywordDemo;

public class test {

	public static void main(String[] args) {
//		Child ch1 = new Child(5);
//		ch1.displayValue();
		Employee E1 = new Employee("test",100,"IT");
		E1.display();
		

	}

}
