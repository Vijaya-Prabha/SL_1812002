package superKeywordDemo;

public class Employee extends Person {
	String name;
	int id;
	String role;
	
	Employee(String name,int id, String role){
		super(name);
		this.id = id;
		this.name = "Employee_"+name;
		this.role =role;
		System.out.println("Employee Class Constructor");
	}
	
	void display() {
		super.display();
		System.out.println("Employee Details:"+super.name+" "+this.id+" "+this.role);
	}

}
