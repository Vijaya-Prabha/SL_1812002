package superKeywordDemo;

public class Employee extends Person{
	String name;
	int id;
	String department;
	
	Employee(String name, int id,String department){
		super(name);
		this.name="Child_"+name;
		this.id = id;
		this.department = department;
		System.out.println("Employee class constructor");
	}
	
	void display() {
		super.display();
		System.out.println("Employee Details: "+super.name+" "+ this.id+" "+this.department);
	}

}
