package superKeywordDemo;

public class Person {
	
	String name;
	
	Person(String x){
		this.name = x;
		System.out.println("Person Constructor");
	}
	
	void display() {
		System.out.println("Person Class: Name:"+this.name);
	}

}
