package superKeywordDemo;

public class Person {
	String name;
	Person(){
		System.out.println("Person No Arg Constructor");
	}

	Person(String x) {
		this.name = x;
		System.out.println("Person Constructor");
	}

	void display() {
		System.out.println("Person name : " + this.name);
	}
}
