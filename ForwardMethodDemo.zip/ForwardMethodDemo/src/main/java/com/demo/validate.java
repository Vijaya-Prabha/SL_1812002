package com.demo;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class validate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName =request.getParameter("uName");
		String password =request.getParameter("password");
		if(userName.equals("abc") && password.equals("123")) {
			PrintWriter writer = response.getWriter();
			response.setContentType("text/html");
			writer.print("<h2>Successfully Logged in!!<h2>");
		}
		else {
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("/register.html");
			requestDispatcher.forward(request, response);
		}
	}

}
