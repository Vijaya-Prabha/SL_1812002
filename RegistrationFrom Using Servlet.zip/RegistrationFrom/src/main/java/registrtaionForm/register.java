package registrtaionForm;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class register extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("inside Class:Get");
		String FirstName = request.getParameter("FName");
		String LastName = request.getParameter("LName");	
		String Email = request.getParameter("Email");
		String UserName = FirstName +" " + LastName;
		System.out.println(Email);
		PrintWriter writer = response.getWriter();
		response.setContentType("text/html");
		writer.print("<h2>Registration Successfull</h2>");
		writer.print("<span> Welcome </span>"+UserName+"<br>");
	writer.print("<span> You can access & modify your account details using this email</span>"+Email);
	}
}

