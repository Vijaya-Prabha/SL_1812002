package Demo;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class validate
 */
public class validate extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName =request.getParameter("uName");
		String password =request.getParameter("password");
		if(userName =="abc" && password=="123") {
			PrintWriter writer = response.getWriter();
			response.setContentType("text/html");
			writer.print("Successfully Logged in!!");
		}
		else {
			
		}
	}

}
